package Ejecutables;
import java.util.ArrayList;

import Librerias.ManejadorArreglos1;

public class PruebaFuncion07102020 {
	public static void imprimeArre(Integer []a, int n) {
		for(int i=0; i<n; i++)
			System.out.println("El dato " + i + " es: " + a[i]);
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ArrayList<Integer> lista = new ArrayList<>();
		Integer [] arre= {16,8,7,6,12};
		
		
		
		
		
		
	}

}
