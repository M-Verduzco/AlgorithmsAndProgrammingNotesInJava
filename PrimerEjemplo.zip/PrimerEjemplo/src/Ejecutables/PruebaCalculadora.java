package Ejecutables;
import Librerias.Calculadora;
import java.util.Scanner;
public class PruebaCalculadora {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int num,num2;
		Scanner lee;
		lee=new Scanner(System.in);
		
//		System.out.println("Dame el numero para aplicar el teorema Ulman");
//		num=lee.nextInt();
//		System.out.println(Calculadora.calculaUllman(num));
		
		
//		System.out.println("Dame dos numeros a mutiplicar");
//		num=lee.nextInt();
//		num2=lee.nextInt();
//		System.out.println(Calculadora.multiplicar(num, num2));
		
		
//		System.out.println("Dame dos numeros: el primero es la base, el segundo el exponente");
//		num=lee.nextInt();
//		num2=lee.nextInt();
//		System.out.println(Calculadora.potencia(num,num2));
		
		
//		System.out.println("Dame el numero para elevarlo al cubo");
//		num=lee.nextInt();
//		System.out.println(Calculadora.generaCubosNicomano(num));
		
		
//		System.out.println("Dame un n�mero para calcular su factorial");
//		num=lee.nextInt();
//		System.out.println(Calculadora.calculaFactorial(num));
		
		
//		System.out.println("Dame dos n�meros para calcular su MCD");
//		num=lee.nextInt();
//		num2=lee.nextInt();
//		System.out.println(Calculadora.calculaMaximoComunDivisor(num, num2));
		
		
//		System.out.println("Dame un numero como tope para la serie de Fibianacci");
//		num=lee.nextInt();
//		System.out.println(Calculadora.generaSerieFibionacci(num));
		
		
//		System.out.println("Dame un numero como tope para la serie de Fibianacci (version de Franzoni)");
//		num=lee.nextInt();
//		System.out.println(Calculadora.generaSerieFibionacci2(num));
		
		
//		System.out.println("Dame un numero para calcular la serie 1");
//		num=lee.nextInt();
//		System.out.println(Calculadora.calculaSerie1(num));
		
		
//		System.out.println("Dame dos numeros para calcular la serie 2");
//		num=lee.nextInt();
//		num2=lee.nextInt();
//		System.out.println(Calculadora.calculaSerie2(num, num2));
		
		
//		System.out.println("Dame dos numeros para calcular la serie 2 (version de Franzoni)");
//		num=lee.nextInt();
//		num2=lee.nextInt();
//		System.out.println(Calculadora.calculaSerie2_2(num, num2));
		
		
//		System.out.println("Dame un numero para calcular la serie 3");
//		num=lee.nextInt();
//		System.out.println(Calculadora.calculaSerie3(num));
		
		
//		System.out.println("Dame un numero para calcular la serie 3 (version de Franzoni");
//		num=lee.nextInt();
//		System.out.println(Calculadora.calculaSerie3(num));
		
	}
	
	
}
