package Ejecutables;
import java.util.ArrayList;

import Librerias.FuncionesTarea15;
public class PruebaTarea15 {


		
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		double [] a = {2.0, 5.0, 10.0, 3.0, 7.0, 8.0, 9.0, 2.0};
		double [] b = {2.0, 9.0, 8.0, 7.0, 3.0, 10.0, 5.0, 2.0};
		
		System.out.println(FuncionesTarea15.esArregloInverso(a,b));
		
		
		
		
		
		Double [] c = {2.0, 5.0, 10.0, 3.0, 7.0, 8.0, 9.0, 12.0};
		Double [] d = {2.0, 9.0, 6.0, 17.0, 3.0, 10.0};
		
	
		System.out.println(FuncionesTarea15.generaInterseccionArreglos(d, c));
		
		
		
		
	}

}
